
import { motion } from 'framer-motion';
import { Sparkles, Wand2, Heart } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-indigo-900 to-black text-white flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <motion.div
        className="absolute inset-0"
        animate={{ opacity: [0.2, 0.5, 0.2] }}
        transition={{ duration: 3, repeat: Infinity }}
      >
        <Sparkles className="w-full h-full text-yellow-200 opacity-10" />
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="text-5xl md:text-6xl font-bold mb-4 text-center bg-clip-text text-transparent bg-gradient-to-r from-pink-400 to-purple-400 drop-shadow-lg"
      >
        Our Magical Friendship ✨
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="text-lg md:text-xl text-pink-200 text-center max-w-2xl mb-10"
      >
        A story of two souls from Hogwarts — one with courage, one with charm, and together they make every moment feel like a spell of joy 💫
      </motion.p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-5xl">
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-gradient-to-tr from-indigo-700 to-purple-700 rounded-2xl shadow-xl p-6 text-center border border-purple-400/20"
        >
          <Wand2 className="w-10 h-10 mx-auto mb-4 text-yellow-300" />
          <h2 className="text-2xl font-semibold mb-2">The Wizard</h2>
          <p className="text-pink-100">A brave boy with a mischievous smile, who’d cast any charm to see his bestie laugh again.</p>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-gradient-to-tr from-pink-700 to-rose-600 rounded-2xl shadow-xl p-6 text-center border border-pink-400/20"
        >
          <Heart className="w-10 h-10 mx-auto mb-4 text-red-300" />
          <h2 className="text-2xl font-semibold mb-2">The Enchantress</h2>
          <p className="text-pink-100">A girl whose laughter feels like a blooming charm — soft, magical, and impossible to forget.</p>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="mt-12 text-center text-lg text-pink-200 italic"
      >
        “Even in a world full of spells, nothing feels stronger than the magic of our bond.”
      </motion.div>

      <footer className="mt-12 text-sm text-pink-300 opacity-70">
        Made with 💖 & a bit of magic — just for her ✨
      </footer>
    </div>
  );
}
